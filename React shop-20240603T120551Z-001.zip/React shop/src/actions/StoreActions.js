import * as types from "../constants/StoreTypes";
import { AddUpdateQty, DeleteProductUpdate, QTYUpdate } from "../Components/common/AddUpdateQty";


export const StoreStateUpdateOne = (data) => async (dispatch, getState) => {
    //const CartProducts = await AddUpdateQty(data, getState().Store.CartProducts);
    const { CartProducts, TotalPrizeVal } = await AddUpdateQty(data, getState().Store.CartProducts);
    console.log(CartProducts, '----StoreStateUpdateOne');
    try {
        dispatch({
            type: types.Store_State_Update,
            payload: { CartProducts, TotalPrizeVal }
        });
    } catch (e) {
        console.log(e);
    }
};


export const DeleteProduct = (data) => async (dispatch, getState) => {

    const { CartProducts, TotalPrizeVal } = await DeleteProductUpdate(data, getState().Store.CartProducts);
    console.log(CartProducts, '----StoreStateUpdateOne');
    try {
        dispatch({
            type: types.Store_State_Update,
            payload: { CartProducts, TotalPrizeVal }
        });
    } catch (e) {
        console.log(e);
    }

}

export const CartQTYUpdate = (data) => async (dispatch, getState) => {
    const { CartProducts, TotalPrizeVal } = await QTYUpdate(data.Index, data.QTY, getState().Store.CartProducts);
    try {
        dispatch({
            type: types.Store_State_Update,
            payload: { CartProducts, TotalPrizeVal }
        });
    } catch (e) {
        console.log(e);
    }
    //const { CartProducts, TotalPrizeVal } = await AddUpdateQty(data, getState().Store.CartProducts);
}