import { Store_Count } from "../constants/StoreTypes";
const initialState = {
    Products: []
};

export default function Cart(state = initialState, action) {
    switch (action.type) {
        case Store_Count:
            return state;
        default:
            return state;
    }
}