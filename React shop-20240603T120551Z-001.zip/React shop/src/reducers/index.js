import { combineReducers } from 'redux'
import Store from './Store'
import Cart from './Cart'

const rootReducer = combineReducers({
    Store,
    Cart
})

export default rootReducer
