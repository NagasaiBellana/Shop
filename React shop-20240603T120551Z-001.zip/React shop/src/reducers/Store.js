import {Store_State_Update } from "../constants/StoreTypes";

const initialState = {
    Products: [],
    User: {},
    Loadrer: false,
    Count: 0,
    CartProducts: [],
    TotalPrizeVal: 0.00
};

export default function Store(state = initialState, action) {
    console.log(action, '-------action');
    switch (action.type) {
        case Store_State_Update:
            return { ...state, ...action.payload };
        default:
            return state;
    }
}