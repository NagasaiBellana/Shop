export const CategoriesJson = [{
    CategoryName: 'Men\'s dresses',
    ProductCount: 10,
    Image: 'cat-1.jpg'
},
{
    CategoryName: 'Women\'s dresses',
    ProductCount: 15,
    Image: 'cat-2.jpg'
},
{
    CategoryName: 'Baby\'s dresses',
    ProductCount: 2,
    Image: 'cat-3.jpg'
},
{
    CategoryName: 'Accerssories',
    ProductCount: 2,
    Image: 'cat-4.jpg'
},
{
    CategoryName: 'Bags',
    ProductCount: 2,
    Image: 'cat-5.jpg'
},
{
    CategoryName: 'Shoes',
    ProductCount: 2,
    Image: 'cat-6.jpg'
}]

export const TrandyProducts = [{
    ProductName: "Colorful Stylish Shirt",
    Prize: '120',
    Sym: '$',
    DisCount: '5',
    Des: '',
    CategoryId: 0,

},
{
    ProductName: "Colorful Stylish Shirt 1",
    Prize: '500',
    Sym: '$',
    DisCount: '25',
    Des: '',
    CategoryId: 1
},
{
    ProductName: "Colorful Stylish Shirt 3",
    Prize: '500',
    Sym: '$',
    DisCount: '0',
    Des: '',
    CategoryId: 2
}]

export const NavbarMenuLinks = [{
    Name: 'Dresses',
    Link: "",
    SubMenu: [{ Name: 'Men\'s Dresses', Link: "" },
    { Name: 'Women\'s Dresses', Link: "" },
    { Name: 'Baby\'s Dresses', Link: "" }]
}, {
    Name: "Shirts",
    Link: ""
},
{
    Name: "Jeans",
    Link: ""
},
{
    Name: "Swimwear",
    Link: ""
},
    ,
{
    Name: "Sleepwear",
    Link: ""
}
    ,
{
    Name: "Sportswear",
    Link: ""
}
    ,
{
    Name: "Jumpsuits",
    Link: ""
},
{
    Name: "Jackets",
    Link: ""
},
    ,
{
    Name: "Shoes",
    Link: ""
}]


export const ProductsData = [{
    ProductName: "Colorful Stylish Shirt Blue",
    Prize: '120',
    Sym: '$',
    DisCount: '5',
    Des: '',
    CategoryId: 0,
    Id: 1,
    color:'Blue',
    size:'XL',
    Popularity: 10
},
{
    ProductName: "Colorful Stylish Shirt 1 Blue",
    Prize: '500',
    Sym: '$',
    DisCount: '25',
    Des: '',
    CategoryId: 1,
    Id: 2,
    color:'Red',
    size:'L',
    Popularity: 5
},
{
    ProductName: "Colorful Stylish Shirt 3",
    Prize: '250',
    Sym: '$',
    DisCount: '0',
    Des: '',
    CategoryId: 2,
    Id: 3,
    color:'Blue',
    size:'Xs',
    Popularity: 15
},
{
    ProductName: "Colorful Stylish Shirt 4",
    Prize: '100',
    Sym: '$',
    DisCount: '3',
    Des: '',
    CategoryId: 1,
    Id: 4,
    color:'Blue',
    size:'XL',
    Popularity: 10
},
{
    ProductName: "Colorful Stylish Shirt 5",
    Prize: '360',
    Sym: '$',
    DisCount: '10',
    Des: '',
    CategoryId: 2,
    Id: 5,
    color:'White',
    size:'S',
    Popularity: 6
},
{
    ProductName: "Colorful Stylish Shirt 6",
    Prize: '410',
    Sym: '$',
    DisCount: '30',
    Des: '',
    CategoryId: 2,
    Id: 6,
    color:'Black',
    size:'M',
    Popularity: 6
},
{
    ProductName: "Colorful Stylish Shirt 7",
    Prize: '940',
    Sym: '$',
    DisCount: '5',
    Des: '',
    CategoryId: 0,
    Id: 7,
    color:'Black',
    sizes: ['XS', 'S', 'M', 'L'],
    Popularity: 6
},
{
    ProductName: "Colorful Stylish Shirt 8",
    Prize: '145',
    Sym: '$',
    DisCount: '25',
    Des: '',
    CategoryId: 1,
    Id: 8,
    color:'Green',
    size:'XS',
    Popularity: 6
},
{
    ProductName: "Colorful Stylish Shirt 9 Blue",
    Prize: '45.89',
    Sym: '$',
    DisCount: '10',
    Des: '',
    CategoryId: 2,
    Id: 9,
    color:'Blue',
    size:'XL',
    Popularity: 9
}]
