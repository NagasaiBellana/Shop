export const ProductsFilter = (ProductsData, props) => {
    console.log(_.size(props.PriceObj), '_size');
    let FilterProductsData = [];
  
    if (
      props.Popularity == 2 ||
      (props.SearchString && props.SearchString.length > 0) ||
      _.size(props.PriceObj) > 0 ||
      _.size(props.SizeObj) > 0 ||
      _.size(props.ColorObj) >0
    ) {
      FilterProductsData = props.Popularity == 2 ? _.orderBy(ProductsData, ['Popularity'], ['desc']) : ProductsData;
  
      if (props.SearchString && props.SearchString.length > 0) {
        FilterProductsData = _.filter(FilterProductsData, (o) => o.ProductName.toLowerCase().search(props.SearchString.toLowerCase()) >= 0);
      }
  
      if (_.size(props.PriceObj) > 0) {
        FilterProductsData = _.filter(FilterProductsData, (o) => o.Prize >= props.PriceObj.Min && o.Prize <= props.PriceObj.Max);
      }
      if (_.size(props.ColorObj) > 0) {
        FilterProductsData = _.filter(FilterProductsData, (o) => o.color===props.ColorObj.Color);
      }
      if (_.size(props.SizeObj) > 0) {
        FilterProductsData = _.filter(FilterProductsData, (o) => o.size===props.SizeObj.Size);
      }
    } else if (props.id > 0) {
      FilterProductsData = _.filter(ProductsData, (o) => o.CategoryId == props.id);
    } else if (props.isHome) {
      FilterProductsData = ProductsData;
    } else {
      FilterProductsData = ProductsData;
    }
  
    console.log(FilterProductsData);
    return FilterProductsData;
  };