import _, { concat } from 'lodash';
import update from 'react-addons-update';
import $ from "jquery";

export const AddUpdateQty = async (product, CartProducts) => {
    ProductFly(product.Id);
    const ProductIndex = _.findIndex(CartProducts, function (o) { return o.Id == product.Id; });
    let CartData = CartProducts;
    if (ProductIndex >= 0) {
        CartData = update(CartProducts, { [ProductIndex]: { QTY: { $set: CartProducts[ProductIndex].QTY + 1 } } });
    } else {
        product.QTY = 1;
        CartData.push(product);
    }
    let TotalPrizeVal = await TotalPrize(CartData);
    console.log(TotalPrizeVal, '----TotalPrizeVal');
    return { CartProducts: CartData, TotalPrizeVal };
}

const ProductFly = (id) => {

    var width = $(window).width();
    var cart = $('.shopping-cart .badge');
    var imgtodrag = $('#product-img-' + id).find("img").eq(0);
    console.log(id, imgtodrag.offset(), imgtodrag.height() / 2);
    if (imgtodrag) {

        var imgclone = imgtodrag.clone()
            .offset({
                top: imgtodrag.offset().top,
                left: imgtodrag.offset().left,
            })
            .css({
                'opacity': '0.5',
                'position': 'absolute',
                'height': imgtodrag.height() / 2,
                'width': imgtodrag.width() / 2,
                'z-index': '100'
            })
            .appendTo($('body'))
            .animate({
                'top': cart.offset().top + 10,
                'left': cart.offset().left + 15,
                'height': imgtodrag.height() / 2,
                'width': imgtodrag.width() / 2
            }, 1000, '');



        imgclone.animate({
            'width': 0,
            'height': 0
        }, function () {
            $(this).detach()
        });
    }

}

const TotalPrize = (CartData) => {
    let sumData = _.sumBy(CartData, function (product) {
        let DisCount = parseFloat(product.DisCount > 0 ? (product.DisCount / 100) * product.Prize : 0);
        console.log(DisCount, product);
        let prize = parseFloat(product.Prize - DisCount).toFixed(2);
        console.log(prize);
        return prize * product.QTY;
    });
    // (10/100)* 100 = 10;

    return sumData
}

export const DeleteProductUpdate = async (product, CartProducts) => {
    const ProductIndex = _.findIndex(CartProducts, function (o) { return o.Id == product.Id; });
    CartProducts.splice(ProductIndex, 1);
    let TotalPrizeVal = await TotalPrize(CartProducts);
    console.log(TotalPrizeVal, '----TotalPrizeVal');
    return { CartProducts, TotalPrizeVal };
}
export const QTYUpdate = async (Index, Qty, CartProducts) => {
    if (Qty > 0) {
        CartProducts = update(CartProducts, { [Index]: { QTY: { $set: Qty } } });
    } else {
        CartProducts.splice(Index, 1);
    }
    let TotalPrizeVal = await TotalPrize(CartProducts);
    console.log(TotalPrizeVal, '----TotalPrizeVal');
    return { CartProducts: CartProducts, TotalPrizeVal };
}