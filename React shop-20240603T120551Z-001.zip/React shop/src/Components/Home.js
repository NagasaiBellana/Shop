import TopBar from "./Topbar";
import Navbar from "./Navbar";
import Featured from "./Featured";
import Categories from "./Categories";
import Offer from "./Offer";
import Products from "./Products";
import Subscribe from "./Subscribe";
import JustArrived from "./JustArrived";
import Vendor from "./Vendor";
import Footer from "./Footer";

import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import PropTypes from 'prop-types';
import * as StoreActions from '../actions/StoreActions'
import _ from 'lodash';
import { GetQrCodeFormTransactions } from './ServiceUrls/Urls'
import axios from 'axios';
import { useEffect } from "react";

const Home = (props) => {

  const AddUpdateQty = (product) => {
    props.actions.StoreStateUpdateOne(product);
  }
  useEffect(() => {
    axios.get(GetQrCodeFormTransactions)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
      GetQrCodeFormTransactionsRequest();
     
  }, [])

  const GetQrCodeFormTransactionsRequest=async()=>{
    const response = await axios({
      method: 'post',
      url: GetQrCodeFormTransactions,
      data: {},
  });
  console.log(response, '==========================================');
  }


  return <>
    <TopBar {...props} />
    <Navbar />
    <Featured />
    <Categories />
    <Offer />
    <Products isHome={1} AddUpdateQty={props.actions.StoreStateUpdateOne} />
    <Subscribe />
    <JustArrived />
    <Vendor />
    <Footer />
  </>

}

Home.propTypes = {
  Count: PropTypes.number.isRequired
}

function mapStateToProps(state) {
  return {
    Count: state.Store.Count,
    Store: state.Store,
    CartProducts: state.Store.CartProducts

  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(Object.assign({}, StoreActions), dispatch)
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Home)

