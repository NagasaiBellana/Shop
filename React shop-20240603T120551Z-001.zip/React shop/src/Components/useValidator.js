import { useState } from 'react'
import SimpleReactValidator from 'simple-react-validator'

const useValidator = (customMessage = {}, customValidator = {}) => {
    const [show, setShow] = useState(false);
    const [hide, setHide] = useState(false);
    const validator = new SimpleReactValidator({
        autoForceUpdate: this,
        validators: {
            Decimal: { // name the rule
                message: 'The :attribute must be . EX(0.1)',
                rule: function (val, params, validator) {
                    return validator.helpers.testRegex(val, /^[-+]?[0-9]+\.[0-9]+$/)
                }
            },

            Time: { // name the rule
                message: 'The :attribute must be valid time(EX 10:00am)',
                rule: function (val, params, validator) {
                    return validator.helpers.testRegex(val, /^0[0-9]|1[0-9]|2[0-3]:[0-5][0-9]$/)
                }
            },
            phone: {
                message: 'The :attribute must be valid.(EX 123-345-3456)',
                rule: function (val, params, validator) {
                    return validator.helpers.testRegex(val, /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)
                }
            }

        },
        element: (message, className) => <div className={'text-danger-error'}>{message.replace(/container/gi, '').replace(/##.*##/, '')}</div>


    })
    if (show) {
        validator.showMessages()
    }

    return [validator, setShow]
}

export default useValidator