import TopBar from "./Topbar";

const ProductDetails = () => {
    return <>
        <TopBar />
    </>
}

export default ProductDetails;