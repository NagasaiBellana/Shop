import Color from '../shop/Color';
import Price from '../shop/price';
import Size from '../shop/Size';
import Sorting from '../shop/Sorting';
import TopBar from "./Topbar";
import Navbar from "./Navbar";
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import PropTypes from 'prop-types';
import Products from "./Products";
import * as StoreActions from '../actions/StoreActions'
import { useState } from 'react';


const Shop = (props) => {
    const [SearchString, setSearchString] = useState('');
    const [Popularity, SortByPopularity] = useState('-1');
    const [PriceObj, setPriceObj] = useState({});
    const [SizeObj, setSizeObj] = useState([]);
    const [ColorObj, setColorObj] = useState([]);


    return <>
        <TopBar {...props} /> <div className="container-fluid pt-5">
            <div className="row px-xl-5">

                <div className="col-lg-3 col-md-12">
                    <Price setPriceObj={setPriceObj} />
                    <Color setColorObj={setColorObj} />
                    <Size setSizeObj={setSizeObj} />
                </div>

                <div className="col-lg-9 col-md-12">
                    <div className="row pb-3">
                        <Sorting SearchByName={setSearchString}
                            SortByPopularity={SortByPopularity}
                            Popularity={Popularity}
                            SearchString={SearchString} />
                        <Products isHome="1"
                            isShop={1}
                            AddUpdateQty={props.actions.StoreStateUpdateOne}
                            SearchString={SearchString}
                            Popularity={Popularity}
                            PriceObj={PriceObj}
                            ColorObj={ColorObj}
                            SizeObj={SizeObj} />
                    </div>
                </div>

            </div>
        </div>
    </>
};

Shop.propTypes = {
    Count: PropTypes.number.isRequired
}

function mapStateToProps(state) {
    return {
        Count: state.Store.Count,
        Store: state.Store,
        CartProducts: state.Store.CartProducts

    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(Object.assign({}, StoreActions), dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Shop)
