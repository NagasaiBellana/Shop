import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import PropTypes from 'prop-types';
import useValidator from './useValidator'
import Swal from 'sweetalert2'
import { useState, useEffect } from 'react';

import TopBar from "./Topbar";
import Footer from "./Footer";

const Checkout = (props) => {
    const AddressObj={FirstName: "", LastName: "", Email: "", MobileNo: ""}
    const [validator, showValidationMessage] = useValidator();
    const [BillingAddress, setBillingAddress]= useState(AddressObj)
    const [ShippingAddress, setShippingAddress]= useState(AddressObj)
    useEffect(()=>{
        setShippingAddress(BillingAddress);
    }, [BillingAddress])
    
    const UpdateFields=async(Field, e)=>{
        setBillingAddress({...BillingAddress, [Field]: e.target.value});
    }
    const ShipAddressasBelling=(e)=>{
        setShippingAddress(BillingAddress);
    }
    const submitForm = async () => {
        console.log(validator);

        if (validator.allValid()) {
            Swal.fire('Oops...', "Order Placed", 'success');

        }else {
          
            showValidationMessage(true);
            const ErrorMessage = 'Please fill out all mandatory fields.'
           Swal.fire('Oops...', ErrorMessage, 'error');
          
        }
    }
    console.log(BillingAddress, 'BillingAddress');
    return <>
        <TopBar {...props}/>
        <div className="container-fluid pt-5">
            <div className="row px-xl-5">
                <div className="col-lg-8">
                    <div className="mb-4">
                        <h4 className="font-weight-semi-bold mb-4">Billing Address</h4>
                        <div className="row">
                            <div className="col-md-6 form-group">
                                <label>First Name</label>
                                <input className="form-control" type="text" placeholder="John" defaultValue={BillingAddress.FirstName} onChange={(e)=>UpdateFields('FirstName', e)} />
                                {validator.message('First Name', BillingAddress.FirstName,'required')}
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Last Name</label>
                                <input className="form-control" type="text" placeholder="Doe" defaultValue={BillingAddress.LastName}  onChange={(e)=>UpdateFields('LastName', e)}/>
                                {validator.message('Last Name', BillingAddress.LastName,'required')}
                            </div>
                            <div className="col-md-6 form-group">
                                <label>E-mail</label>
                                <input className="form-control" type="text" placeholder="example@email.com" defaultValue={BillingAddress.Email} onChange={(e)=>UpdateFields('Email', e)}/>
                                {validator.message('E-mail', BillingAddress.Email,'required|email')}
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Mobile No</label>
                                <input className="form-control" type="text" placeholder="+123 456 789" defaultValue={BillingAddress.MobileNo}  onChange={(e)=>UpdateFields('MobileNo', e)}/>
                                {validator.message('Mobile No', BillingAddress.MobileNo,'Decimal|required')}
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Address Line 1</label>
                                <input className="form-control" type="text" placeholder="123 Street" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Address Line 2</label>
                                <input className="form-control" type="text" placeholder="123 Street" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Country</label>
                                <select className="custom-select">
                                    <option defaultValue>United States</option>
                                    <option>Afghanistan</option>
                                    <option>Albania</option>
                                    <option>Algeria</option>
                                </select>
                            </div>
                            <div className="col-md-6 form-group">
                                <label>City</label>
                                <input className="form-control" type="text" placeholder="New York" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>State</label>
                                <input className="form-control" type="text" placeholder="New York" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>ZIP Code</label>
                                <input className="form-control" type="text" placeholder="123" />
                            </div>
                            <div className="col-md-12 form-group">
                                <div className="custom-control custom-checkbox">
                                    <input type="checkbox" className="custom-control-input" id="newaccount" />
                                    <label className="custom-control-label" htmlFor="newaccount">Create an account</label>
                                </div>
                            </div>
                            <div className="col-md-12 form-group">
                                <div className="custom-control custom-checkbox">
                                    <input type="checkbox" className="custom-control-input" id="shipto" onClick={(e)=>ShipAddressasBelling(e)} />
                                    <label className="custom-control-label" htmlFor="shipto" data-toggle="collapse" data-target="#shipping-address">Ship to different address</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="collapse mb-4" id="shipping-address">
                        <h4 className="font-weight-semi-bold mb-4">Shipping Address</h4>
                        <div className="row">
                            <div className="col-md-6 form-group">
                                <label>First Name</label>
                                <input className="form-control" type="text" placeholder="John" defaultValue={ShippingAddress.FirstName}/>
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Last Name</label>
                                <input className="form-control" type="text" placeholder="Doe" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>E-mail</label>
                                <input className="form-control" type="text" placeholder="example@email.com" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Mobile No</label>
                                <input className="form-control" type="text" placeholder="+123 456 789" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Address Line 1</label>
                                <input className="form-control" type="text" placeholder="123 Street" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Address Line 2</label>
                                <input className="form-control" type="text" placeholder="123 Street" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>Country</label>
                                <select className="custom-select">
                                    <option defaultValue>United States</option>
                                    <option>Afghanistan</option>
                                    <option>Albania</option>
                                    <option>Algeria</option>
                                </select>
                            </div>
                            <div className="col-md-6 form-group">
                                <label>City</label>
                                <input className="form-control" type="text" placeholder="New York" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>State</label>
                                <input className="form-control" type="text" placeholder="New York" />
                            </div>
                            <div className="col-md-6 form-group">
                                <label>ZIP Code</label>
                                <input className="form-control" type="text" placeholder="123" />
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="card border-secondary mb-5">
                        <div className="card-header bg-secondary border-0">
                            <h4 className="font-weight-semi-bold m-0">Order Total</h4>
                        </div>
                        <div className="card-body">
                            <h5 className="font-weight-medium mb-3">Products</h5>
                            {props.CartProducts.map((product, Index) => {
                                let DisCount = parseFloat(product.DisCount > 0 ? (product.DisCount / 100) * product.Prize : 0);
                                let prize = parseFloat(product.Prize - DisCount).toFixed(2);
                                return <div className="d-flex justify-content-between" key={Index}>
                                    <p>{product.ProductName}</p>
                                    <p>${(prize * product.QTY).toFixed(2)}</p>
                                </div>
                            })}

                            <hr className="mt-0" />
                            <div className="d-flex justify-content-between mb-3 pt-1">
                                <h6 className="font-weight-medium">Subtotal</h6>
                                <h6 className="font-weight-medium">${props.TotalPrizeVal}</h6>
                            </div>
                            <div className="d-flex justify-content-between">
                                <h6 className="font-weight-medium">Shipping</h6>
                                <h6 className="font-weight-medium">$10</h6>
                            </div>
                        </div>
                        <div className="card-footer border-secondary bg-transparent">
                            <div className="d-flex justify-content-between mt-2">
                                <h5 className="font-weight-bold">Total</h5>
                                <h5 className="font-weight-bold">${props.TotalPrizeVal}</h5>
                            </div>
                        </div>
                    </div>
                    <div className="card border-secondary mb-5">
                        <div className="card-header bg-secondary border-0">
                            <h4 className="font-weight-semi-bold m-0">Payment</h4>
                        </div>
                        <div className="card-body">
                            <div className="form-group">
                                <div className="custom-control custom-radio">
                                    <input type="radio" className="custom-control-input" name="payment" id="paypal" />
                                    <label className="custom-control-label" htmlFor="paypal">Paypal</label>
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="custom-control custom-radio">
                                    <input type="radio" className="custom-control-input" name="payment" id="directcheck" />
                                    <label className="custom-control-label" htmlFor="directcheck">Direct Check</label>
                                </div>
                            </div>
                            <div className="">
                                <div className="custom-control custom-radio">
                                    <input type="radio" className="custom-control-input" name="payment" id="banktransfer" />
                                    <label className="custom-control-label" htmlFor="banktransfer">Bank Transfer</label>
                                </div>
                            </div>
                        </div>
                        <div className="card-footer border-secondary bg-transparent">
                            <button className="btn btn-lg btn-block btn-primary font-weight-bold my-3 py-3" onClick={()=>submitForm()}>Place Order</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </>
}


Checkout.propTypes = {
    Count: PropTypes.number.isRequired
}

function mapStateToProps(state) {
    return {
        Count: state.Store.Count,
        Store: state.Store,
        CartProducts: state.Store.CartProducts,
        TotalPrizeVal: state.Store.TotalPrizeVal

    }
}

function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(Object.assign({}), dispatch)
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Checkout)
