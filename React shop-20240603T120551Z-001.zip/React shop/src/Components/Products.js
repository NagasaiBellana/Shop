import { ProductsData } from "../JsonData";
import {ProductsFilter} from "../Components/common/ProductsFilter";

const Products = (props) => {
    console.log(props, '-------Products');
    const ProductsList = ProductsFilter(ProductsData, props);
   // const ProductsList = (props.isHome ? ProductsData : _.filter(ProductsData, function (o) { return o.CategoryId == props.id; }));
    return <div className="container-fluid pt-5">
        <div className="text-center mb-4">
            <h2 className="section-title px-5"><span className="px-2">Trandy Products</span></h2>
        </div>
        <div className="row px-xl-5 pb-3">

            {ProductsList.map((product, index) => {
                let DisCount = parseFloat(product.DisCount > 0 ? (product.DisCount / 100) * product.Prize : 0);
                return <div className={"col-lg-" + (props.isShop ? '4' : '3') + " col-md-6 col-sm-12 pb-1"} key={product.Id} id={`product-img-${product.Id}`}>
                    <div className="card product-item border-0 mb-4">
                        <div className="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                            <a href={"/product-details/" + index + "/" + product.ProductName}>
                                <img className="img-fluid w-100" src={"/img/product-" + product.Id + ".jpg"} alt="" key={product.Id} /></a>
                        </div>
                        <div className="card-body border-left border-right text-center p-0 pt-4 pb-3">
                            <a href={"/product-details/" + index + "/" + product.ProductName}>
                                <h6 className="text-truncate mb-3">{product.ProductName}</h6>
                            </a>
                            <div className="d-flex justify-content-center">
                                <h6>{product.Sym}{parseFloat(product.Prize - DisCount).toFixed(2)}</h6>{product.DisCount > 0 && <h6 className="text-muted ml-2"><del>{product.Sym}{product.Prize}</del></h6>}
                            </div>
                        </div>
                        <div className="card-footer d-flex justify-content-between bg-light border">
                            <a href={"/product-details/" + index + "/" + product.ProductName} className="btn btn-sm text-dark p-0"><i className="fas fa-eye text-primary mr-1"></i>View Detail</a>
                            <a className="btn btn-sm text-dark p-0" onClick={() => props.AddUpdateQty(product)}><i className="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</a>
                        </div>
                    </div>
                </div>
            })}

        </div>
    </div>
}

export default Products;