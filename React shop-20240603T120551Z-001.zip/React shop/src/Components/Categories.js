import { CategoriesJson } from "../JsonData";

const Categories = () => {

    return <div className="container-fluid pt-5">
        <div className="row px-xl-5 pb-3">
            {CategoriesJson.map((Category, index) => {
                return <div className="col-lg-4 col-md-6 pb-1" key={index}>
                    <div className="cat-item d-flex flex-column border mb-4" style={{ padding: 30 }}>
                        <p className="text-right">{Category.ProductCount} Products</p>
                        <a href="" className="cat-img position-relative overflow-hidden mb-3">
                            <img className="img-fluid" src={"img/" + Category.Image} alt="" />
                        </a>
                        <h5 className="font-weight-semi-bold m-0">{Category.CategoryName}</h5>
                    </div>
                </div>
            })}
        </div>
    </div>
}

export default Categories;