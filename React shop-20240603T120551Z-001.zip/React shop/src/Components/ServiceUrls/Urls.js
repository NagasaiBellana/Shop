//export const GetQrCodeFormTransactions = '//dummyjson.com/test';//
// ServiceUrls/Urls.js
export const GetQrCodeFormTransactions = 'https://jsonplaceholder.cypress.io/posts';
