import TopBar from "./Topbar";
import Navbar from "./Navbar";
import Featured from "./Featured";
import Categories from "./Categories";
import Offer from "./Offer";
import Products from "./Products";
import Subscribe from "./Subscribe";
import JustArrived from "./JustArrived";
import Vendor from "./Vendor";
import Footer from "./Footer";
import { useParams } from 'react-router-dom';


const CategoryProducts = (props) => {
    const params = useParams()
    return <>
        <TopBar />
        <Navbar />
        <Products {...params} />
        <Footer />
    </>
}

export default CategoryProducts;