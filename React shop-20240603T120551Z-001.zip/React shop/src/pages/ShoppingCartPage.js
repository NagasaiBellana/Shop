import React from 'react';
import ShoppingCart from '../Components/ShoppingCart'; // Update import path if needed

const ShoppingCartPage = () => {
  console.log('Rendering ShoppingCartPage component');

  return (
    <div>
      <h1>Shopping Cart Page</h1>
      <ShoppingCart />
      {/* Add other content specific to the shopping cart page */}
    </div>
  );
};

export default ShoppingCartPage;
