
import React from 'react';
import HomeMenu from '../Components/HomeMenu';

const HomePage = () => {
  return (
    <div>
      <h1>Home</h1>
      <HomeMenu />
    </div>
  );
};

export default HomePage;
