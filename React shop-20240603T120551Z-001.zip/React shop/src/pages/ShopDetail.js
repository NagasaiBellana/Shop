import React from 'react';
import Detail from '../Components/Detail';

const ShopDetail = () => {
  console.log('Rendering ShopDetail component');

  return (
    <div>
      <h1>ShopDetail</h1>
      <Detail />
    </div>
  );
};

export default ShopDetail;
