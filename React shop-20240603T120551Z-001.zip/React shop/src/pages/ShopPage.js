// ShopPage.js
import React from 'react';
import Shop from '../Components/Shop'; // Import the Shop component

const ShopPage = () => {
  return (
    <div>
      <h1>Shop Page</h1>
      <Shop />
    </div>
  );
};

export default ShopPage;
