import React from 'react';
import CheckoutTab from '../Components/CheckoutTab'; // Update import path if needed

const CheckoutTabPage = () => {
  console.log('Rendering CheckoutTabPage component');

  return (
    <div>
      <h1>CheckoutTabPage</h1>
      <CheckoutTab />
      {/* Add other content specific to the checkout tab page */}
    </div>
  );
};

export default CheckoutTabPage;
