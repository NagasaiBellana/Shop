import React from 'react'

const Color = (props) => {
        const FilterColor=[{Color:'Black',Qty:150},{Color:'White',Qty:295},{Color:'Red',Qty:246},{Color:'Blue',Qty:145},{Color:'Green',Qty:168}]
        const UpdateColorObj=(e,obj)=>{
            if (e.target.checked){
                props.setColorObj(obj)
            }else{
                props.setColorObj({})
            }
            console.log(e,obj,e.target.checked);
        }
  return (
    <>
    <div className="border-bottom mb-4 pb-4">
        <h5 className="font-weight-semi-bold mb-4">Filter by color</h5>
        <form>
            <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                <input type="checkbox" className="custom-control-input"  id="color-all"  onClick={(e) => UpdateColorObj(e, {})}/>
                <label className="custom-control-label" htmlFor="price-all">All Color</label>
                <span className="badge border font-weight-normal">1000</span>
            </div>
            {FilterColor.map((obj,index)=>{
                return <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3"key={index}>
                <input type="checkbox" className="custom-control-input" id={"color-"+index} onClick={(e)=>(UpdateColorObj(e,obj))}/>
                <label className="custom-control-label" htmlFor={"color-"+index}>{obj.Color}</label>
                <span className="badge border font-weight-normal">{obj.Qty}</span>
            </div>
            })}
        </form>
    </div>
    </>
  )
}

export default Color;