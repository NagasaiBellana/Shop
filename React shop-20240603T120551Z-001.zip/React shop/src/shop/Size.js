import React from 'react'

const Size = (props) => {
  const FilterSize = [{ Size: 'XS', Qty: 150 }, { Size: 'S', Qty: 295 }, { Size: 'M', Qty: 246 }, { Size: 'L', Qty: 145 }, { Size: 'XL', Qty: 168 }]
  const UpdateSizeObj = (e, obj) => {
    if (e.target.checked) {
      props.setSizeObj(obj)
    } else {
      props.setSizeObj({})
    }
    console.log(e, obj, e.target.checked);
  }
  return (
    <>
      <div className="mb-5">
        <h5 className="font-weight-semi-bold mb-4">Filter by size</h5>
        <form>
          <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
            <input type="checkbox" className="custom-control-input" id="size-all" />
            <label className="custom-control-label" htmlFor="size-all">All Size</label>
            <span className="badge border font-weight-normal">1000</span>
          </div>
          {FilterSize.map((obj, index) => {
            return <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3" key={index}>
              <input type="checkbox" className="custom-control-input" id={"size-" + index} onClick={(e) => (UpdateSizeObj(e, obj))} />
              <label className="custom-control-label" htmlFor={"size-" + index}>{obj.Size}</label>
              <span className="badge border font-weight-normal">{obj.Qty}</span>
            </div>
          })}
        </form>
      </div>
    </>
  )
}

export default Size;
