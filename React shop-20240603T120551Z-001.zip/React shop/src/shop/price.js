const Price = (props) => {
    const FilterPriceArray = [
        { Price: '$0   - $100', Min: 0, Max: '100' },
        { Price: '$100 - $200', Min: 100, Max: '200' },
        { Price: '$200 - $300', Min: 200, Max: '300' },
        { Price: '$300 - $400', Min: 300, Max: '400' },
        { Price: '$400 - $500', Min: 400, Max: '500' }
    ];
    const UpdatePriceObj = (e, obj) => {
        if (e.target.checked) {
            props.setPriceObj(obj);
        } else {
            props.setPriceObj({});
        }
    }


    return <div className="border-bottom mb-4 pb-4">
        <h5 className="font-weight-semi-bold mb-4">Filter by Price</h5>
        <form>
            <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                <input type="checkbox" className="custom-control-input" defaultChecked id="Price-all" />
                <label className="custom-control-label" htmlFor="Price-all">All Price</label>
                <span className="badge border font-weight-normal">1000</span>
            </div>
            {FilterPriceArray.map((obj, index) => {
                return <div className="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3" key={index}>
                    <input type="checkbox" className="custom-control-input" id={"price-" + index} onClick={(e) => { UpdatePriceObj(e, obj) }} />
                    <label className="custom-control-label" htmlFor={"price-" + index}>{obj.Price}</label>
                    <span className="badge border font-weight-normal">150</span>
                </div>
            })}
        </form>
    </div>
}
export default Price;