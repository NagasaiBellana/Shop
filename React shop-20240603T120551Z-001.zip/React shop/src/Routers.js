import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './Components/Home';
import CategoryProducts from './Components/CategoryProducts';
import ProductDetails from './Components/ProductDetails';
import Cart from './Components/Cart';
import Checkout from './Components/Checkout';
import configureStore from './store/configureStore';
import { Provider } from 'react-redux';
import { createBrowserHistory } from 'history';
import ShopDetail from './pages/ShopDetail';
import ShopPage from './pages/ShopPage';
import ContactPage from './pages/ContactPage'; 
import ShoppingCartPage from './pages/ShoppingCartPage';
import CheckoutTabPage from './pages/CheckoutTabPage'; 
import HomePage from './pages/HomePage';
import Shop from './Components/Shop';


const history = createBrowserHistory();
const store = configureStore();

export default function AppRouter() {
  return (
    <Provider store={store}>
      <Router history={history}>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/category/:id/:categoryName" element={<CategoryProducts />} />
          <Route exact path="/category/:id?/:categoryName?/:subId?/:subMenu?" element={<CategoryProducts />} />
          <Route exact path="/product-details/:id?/:ProductName?" element={<ProductDetails />} />
          <Route exact path="/cart-details" element={<Cart />} />
          <Route exact path="/checkout" element={<Checkout />} />

          <Route exact path="/homemenu" element={<HomePage />} />
          <Route exact path="/shop" element={<ShopPage />} />
          <Route exact path="/Shop" element={<Shop />} />
          <Route exact path="/contact" element={<ContactPage />} /> 
          <Route exact path="/shopdetail" element={<ShopDetail />} />
          <Route exact path="/cart" element={<ShoppingCartPage />} />
          <Route exact path="/checkout" element={<CheckoutTabPage />} />
          <Route exact path="*" element={""} />
        </Routes>
      </Router>
    </Provider>
  );
}
